# Example 1

A purposely simple example containing data for a single plot.
Data in the example is not real, it's arbitrary and only serves demonstration purposes.

# Instructions

Create a tar file containing both ex1.yaml and submission.yaml.
Use the "sandbox" feature of HEPData to upload
to the private testing area and observe the result of the upload.
The data can be tweaked and re-uploaded to the same sandbox if you
want to check how modified inputs affects the displayed data.

