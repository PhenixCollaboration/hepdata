The formatter.py takes an input file named "Nch.txt" and outputs a file named "Nch_formatted.txt" with the correct significant digits. 
The headers in Nch.txt should be commented out with # or ""
To run the code: "python formatter.py"
